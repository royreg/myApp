package com.example.roy.newapp;

/**
 * Created by Roy on 06/01/2017.
 */

public class Quote {
    protected String quote;
    protected String author;
    protected String category;
    protected String cat;

}

